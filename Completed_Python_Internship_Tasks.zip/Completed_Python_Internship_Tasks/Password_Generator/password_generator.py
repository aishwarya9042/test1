import random,string
n=int(input('Length: '))
c=string.ascii_letters+string.digits+string.punctuation
print('Password:',''.join(random.choice(c) for _ in range(n)))
