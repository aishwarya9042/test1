prices={'AAPL':180,'TSLA':250,'GOOGL':150}
total=0
for s in prices:
 q=int(input(f'Quantity of {s}: '))
 total+=q*prices[s]
print('Total Investment = $',total)
