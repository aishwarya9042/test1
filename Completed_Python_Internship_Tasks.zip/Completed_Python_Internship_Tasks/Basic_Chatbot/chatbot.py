while True:
 m=input('You: ').lower()
 if m=='bye': print('Bot: Goodbye!'); break
 elif 'hello' in m: print('Bot: Hello!')
 elif 'name' in m: print('Bot: I am ChatBot.')
 else: print('Bot: I did not understand.')
