# Hangman Game
Run: python hangman.py